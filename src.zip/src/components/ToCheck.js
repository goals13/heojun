import React, {Component, Fragment} from 'react';
import InputForm from './check/InputForm';
import './ToCheck.scss';


class ToCheck extends Component {
    render() {
      return (
        <div>
          <InputForm />
        </div>
      );
    }
  }

export default ToCheck;