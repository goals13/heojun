import React from 'react';
import View from  "./View";

const ViewResult = () => {
    return (
        <div>
            <View />
        </div>
    );
};

export default ViewResult;